from django.apps import AppConfig


class CaradConfig(AppConfig):
    name = 'carAd'
