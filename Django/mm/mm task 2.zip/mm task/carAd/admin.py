from django.contrib import admin

from carAd.models import *

admin.site.register(Type)
admin.site.register(Specification)
admin.site.register(CarPost)
admin.site.register(CarPostPicture)
